=== Tónsmiðjan ===

Þema fyrir Tónsmiðju Suðurlands.

== Uppsetning ==
1. Útlit › Þemu › Bæta við › Hlaða upp þema. Veldu tonsmidjan.zip.
2. Ýttu á „Forskoða“ til að skoða áður en þú virkjar, svo „Virkja“.
3. Logo: Útlit › Ritill › Haus. Smelltu á logo-reitinn og veldu myndina.
   Ef logoið inniheldur nafn skólans má eyða titlinum við hliðina.
4. Valmynd: Útlit › Ritill › Haus › Valmynd. Veldu síður eða núverandi valmynd.

== Að breyta forsíðunni ==
Útlit › Ritill › Sniðmát › Forsíða. Smelltu á texta til að breyta honum.
Bakgrunnsmynd í efsta hluta: smelltu á dökka svæðið og veldu „Bæta við mynd“.

== Mynstur ==
Allir hlutar forsíðunnar eru líka mynstur sem má setja á aðrar síður:
smelltu á + í ritlinum › Mynstur › Tónsmiðjan.
Þar er líka „Verðskrá“, tafla til að fylla inn.

== Slóðir ==
„Sækja um“ vísar á https://istonsmidjan.speedadmin.dk/registration#/
„Netnám“ vísar á https://eythor92.github.io/tonsmidjan-netnam/
Breyttu slóðunum með því að smella á hnappana í ritlinum.

== Leturgerðir ==
Archivo og Inter, SIL Open Font License (sjá assets/fonts).
