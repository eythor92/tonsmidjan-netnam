<?php
/**
 * Title: Forsíða – kynning
 * Slug: tonsmidjan/hero
 * Categories: tonsmidjan, banner
 * Description: Stór kynning efst á forsíðu með fyrirsögn og hnöppum. Hægt er að setja ljósmynd í bakgrunninn.
 * Viewport Width: 1400
 */
?>
<!-- wp:cover {"overlayColor":"ink","isUserOverlayColor":true,"dimRatio":100,"minHeight":600,"minHeightUnit":"px","align":"full","className":"tsn-hero","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull tsn-hero" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70);min-height:600px"><span aria-hidden="true" class="wp-block-cover__background has-ink-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container">
<!-- wp:group {"align":"wide","layout":{"type":"constrained","contentSize":"720px","justifyContent":"left"}} -->
<div class="wp-block-group alignwide">
<!-- wp:paragraph {"className":"tsn-pill","style":{"spacing":{"padding":{"top":"6px","bottom":"6px","left":"14px","right":"14px"}},"border":{"radius":"999px"},"typography":{"fontWeight":"600"}},"backgroundColor":"dark-2","textColor":"mint","fontSize":"small"} -->
<p class="tsn-pill has-mint-color has-dark-2-background-color has-text-color has-background has-small-font-size" style="border-radius:999px;padding-top:6px;padding-right:14px;padding-bottom:6px;padding-left:14px;font-weight:600">Tónlistarskóli á Suðurlandi</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"textColor":"white"} -->
<h1 class="wp-block-heading has-white-color has-text-color">Þitt líf. Þín sál.<br>Þín tónlist.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"on-dark","fontSize":"large"} -->
<p class="has-on-dark-color has-text-color has-large-font-size">Nám á hljóðfæri, söngur og tónlistartækni fyrir börn og fullorðna. Þú velur tónlistina, við hjálpum þér að ná tökum á henni.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="https://istonsmidjan.speedadmin.dk/registration#/">Sækja um nám</a></div>
<!-- /wp:button -->
<!-- wp:button {"backgroundColor":"white","textColor":"ink","className":"is-style-fill"} -->
<div class="wp-block-button is-style-fill"><a class="wp-block-button__link has-ink-color has-white-background-color has-text-color has-background wp-element-button" href="#nam">Nám í boði</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
