<?php
/**
 * Title: Netnám
 * Slug: tonsmidjan/netnam
 * Categories: tonsmidjan, call-to-action
 * Description: Kynning á netnámi Tónsmiðjunnar með skrefunum fjórum.
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","anchor":"netnam","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}},"border":{"top":{"color":"var:preset|color|line","width":"1px"},"bottom":{"color":"var:preset|color|line","width":"1px"}}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<section id="netnam" class="wp-block-group alignfull has-white-background-color has-background" style="border-top-color:var(--wp--preset--color--line);border-top-width:1px;border-bottom-color:var(--wp--preset--color--line);border-bottom-width:1px;margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%">
<!-- wp:paragraph {"className":"tsn-pill","style":{"spacing":{"padding":{"top":"6px","bottom":"6px","left":"14px","right":"14px"}},"border":{"radius":"999px"},"typography":{"fontWeight":"600"}},"backgroundColor":"accent-soft","textColor":"accent-hover","fontSize":"small"} -->
<p class="tsn-pill has-accent-hover-color has-accent-soft-background-color has-text-color has-background has-small-font-size" style="border-radius:999px;padding-top:6px;padding-right:14px;padding-bottom:6px;padding-left:14px;font-weight:600">Nýtt: Netnám</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Æfðu þig heima, á þínum tíma</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"large"} -->
<p class="has-ink-2-color has-text-color has-large-font-size">Kennslumyndbönd, nótur og æfingaplön sem opnast eina viku í einu. Þú sendir kennaranum upptöku og færð persónulega endurgjöf. Engir fastir tímar.</p>
<!-- /wp:paragraph -->
<!-- wp:group {"style":{"spacing":{"blockGap":"20px","margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"grid","minimumColumnWidth":"220px"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--40);margin-bottom:var(--wp--preset--spacing--40)">
<!-- wp:group {"style":{"spacing":{"blockGap":"14px"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"tsn-step-num","style":{"border":{"radius":"50%"},"typography":{"fontWeight":"800","fontSize":"18px"}},"backgroundColor":"accent","textColor":"white","fontFamily":"archivo"} -->
<p class="tsn-step-num has-white-color has-accent-background-color has-text-color has-background has-archivo-font-family" style="border-radius:50%;font-size:18px;font-weight:800">1</p>
<!-- /wp:paragraph -->
<!-- wp:group {"style":{"spacing":{"blockGap":"2px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}},"fontFamily":"archivo"} -->
<p class="has-archivo-font-family" style="font-weight:700">Horfðu á kennsluna</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Myndband og nótur fyrir hverja viku.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
<!-- wp:group {"style":{"spacing":{"blockGap":"14px"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"tsn-step-num","style":{"border":{"radius":"50%"},"typography":{"fontWeight":"800","fontSize":"18px"}},"backgroundColor":"accent","textColor":"white","fontFamily":"archivo"} -->
<p class="tsn-step-num has-white-color has-accent-background-color has-text-color has-background has-archivo-font-family" style="border-radius:50%;font-size:18px;font-weight:800">2</p>
<!-- /wp:paragraph -->
<!-- wp:group {"style":{"spacing":{"blockGap":"2px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}},"fontFamily":"archivo"} -->
<p class="has-archivo-font-family" style="font-weight:700">Æfðu þig heima</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Æfingaplan fyrir hvern dag.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
<!-- wp:group {"style":{"spacing":{"blockGap":"14px"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"tsn-step-num","style":{"border":{"radius":"50%"},"typography":{"fontWeight":"800","fontSize":"18px"}},"backgroundColor":"accent","textColor":"white","fontFamily":"archivo"} -->
<p class="tsn-step-num has-white-color has-accent-background-color has-text-color has-background has-archivo-font-family" style="border-radius:50%;font-size:18px;font-weight:800">3</p>
<!-- /wp:paragraph -->
<!-- wp:group {"style":{"spacing":{"blockGap":"2px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}},"fontFamily":"archivo"} -->
<p class="has-archivo-font-family" style="font-weight:700">Sendu upptöku</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Beint úr símanum til kennarans.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
<!-- wp:group {"style":{"spacing":{"blockGap":"14px"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"tsn-step-num","style":{"border":{"radius":"50%"},"typography":{"fontWeight":"800","fontSize":"18px"}},"backgroundColor":"accent","textColor":"white","fontFamily":"archivo"} -->
<p class="tsn-step-num has-white-color has-accent-background-color has-text-color has-background has-archivo-font-family" style="border-radius:50%;font-size:18px;font-weight:800">4</p>
<!-- /wp:paragraph -->
<!-- wp:group {"style":{"spacing":{"blockGap":"2px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}},"fontFamily":"archivo"} -->
<p class="has-archivo-font-family" style="font-weight:700">Fáðu endurgjöf</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Persónuleg ráð um næstu skref.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="https://eythor92.github.io/tonsmidjan-netnam/">Kynna mér netnámið</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:group {"style":{"spacing":{"padding":{"top":"32px","bottom":"32px","left":"32px","right":"32px"},"blockGap":"10px"},"border":{"radius":"20px"}},"backgroundColor":"ink","textColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group has-white-color has-ink-background-color has-text-color has-background" style="border-radius:20px;padding-top:32px;padding-right:32px;padding-bottom:32px;padding-left:32px">
<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700","letterSpacing":"0.06em","textTransform":"uppercase"}},"textColor":"mint","fontSize":"small"} -->
<p class="has-mint-color has-text-color has-small-font-size" style="font-weight:700;letter-spacing:0.06em;text-transform:uppercase">Opið fyrir skráningu</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"fontSize":"xx-large"} -->
<h3 class="wp-block-heading has-xx-large-font-size">Píanó</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"on-dark"} -->
<p class="has-on-dark-color has-text-color">Grunnnámskeið, námskeið 2 og námskeið 3. Fjórar vikur hvert, ein lota á viku. Fyrsta vikan er ókeypis prufa.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"on-dark","fontSize":"small"} -->
<p class="has-on-dark-color has-text-color has-small-font-size">Fleiri hljóðfæri bætast við á næstunni.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</section>
<!-- /wp:group -->
