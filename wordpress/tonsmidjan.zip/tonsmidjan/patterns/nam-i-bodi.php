<?php
/**
 * Title: Nám í boði
 * Slug: tonsmidjan/nam-i-bodi
 * Categories: tonsmidjan, featured
 * Description: Yfirlit yfir hljóðfæri, söng og tónlistartækni.
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","anchor":"nam","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"},"blockGap":"var:preset|spacing|50"}},"backgroundColor":"ground","layout":{"type":"constrained"}} -->
<section id="nam" class="wp-block-group alignfull has-ground-background-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"12px"}},"layout":{"type":"constrained","contentSize":"640px","justifyContent":"left"}} -->
<div class="wp-block-group alignwide">
<!-- wp:heading -->
<h2 class="wp-block-heading">Nám í boði</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2"} -->
<p class="has-ink-2-color has-text-color">Við kennum á öll helstu hljóðfærin og reynum að verða við óskum ef þig langar að læra á eitthvað annað.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"16px"}},"layout":{"type":"grid","minimumColumnWidth":"220px"}} -->
<div class="wp-block-group alignwide">
<!-- wp:group {"className":"tsn-instrument","style":{"spacing":{"padding":{"top":"20px","bottom":"20px","left":"22px","right":"22px"},"blockGap":"4px"},"border":{"radius":"16px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-instrument has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:16px;padding-top:20px;padding-right:22px;padding-bottom:20px;padding-left:22px">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Píanó</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Klassík og popp, nótnalestur og hljómar.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"tsn-instrument","style":{"spacing":{"padding":{"top":"20px","bottom":"20px","left":"22px","right":"22px"},"blockGap":"4px"},"border":{"radius":"16px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-instrument has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:16px;padding-top:20px;padding-right:22px;padding-bottom:20px;padding-left:22px">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Hljómborð</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Hljómar, undirleikur og hljóðgervlar.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"tsn-instrument","style":{"spacing":{"padding":{"top":"20px","bottom":"20px","left":"22px","right":"22px"},"blockGap":"4px"},"border":{"radius":"16px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-instrument has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:16px;padding-top:20px;padding-right:22px;padding-bottom:20px;padding-left:22px">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Gítar</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Kassagítar og rafgítar, hljómar og lög.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"tsn-instrument","style":{"spacing":{"padding":{"top":"20px","bottom":"20px","left":"22px","right":"22px"},"blockGap":"4px"},"border":{"radius":"16px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-instrument has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:16px;padding-top:20px;padding-right:22px;padding-bottom:20px;padding-left:22px">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Bassi</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Grunnurinn í hverri hljómsveit.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"tsn-instrument","style":{"spacing":{"padding":{"top":"20px","bottom":"20px","left":"22px","right":"22px"},"blockGap":"4px"},"border":{"radius":"16px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-instrument has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:16px;padding-top:20px;padding-right:22px;padding-bottom:20px;padding-left:22px">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Trommur</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Taktur, samhæfing og hljómsveitarspil.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"tsn-instrument","style":{"spacing":{"padding":{"top":"20px","bottom":"20px","left":"22px","right":"22px"},"blockGap":"4px"},"border":{"radius":"16px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-instrument has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:16px;padding-top:20px;padding-right:22px;padding-bottom:20px;padding-left:22px">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Ukulele</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Einfalt og skemmtilegt fyrsta hljóðfæri.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"tsn-instrument","style":{"spacing":{"padding":{"top":"20px","bottom":"20px","left":"22px","right":"22px"},"blockGap":"4px"},"border":{"radius":"16px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-instrument has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:16px;padding-top:20px;padding-right:22px;padding-bottom:20px;padding-left:22px">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Harmonikka</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Hefðbundin tónlist og ný.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"tsn-instrument","style":{"spacing":{"padding":{"top":"20px","bottom":"20px","left":"22px","right":"22px"},"blockGap":"4px"},"border":{"radius":"16px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-instrument has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:16px;padding-top:20px;padding-right:22px;padding-bottom:20px;padding-left:22px">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Þverflauta</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Tónmyndun, lög og samspil.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"tsn-instrument","style":{"spacing":{"padding":{"top":"20px","bottom":"20px","left":"22px","right":"22px"},"blockGap":"4px"},"border":{"radius":"16px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-instrument has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:16px;padding-top:20px;padding-right:22px;padding-bottom:20px;padding-left:22px">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Blokkflauta</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">Fyrstu skrefin í tónlistinni.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"20px"}},"layout":{"type":"grid","minimumColumnWidth":"420px"}} -->
<div class="wp-block-group alignwide">
<!-- wp:group {"style":{"spacing":{"padding":{"top":"32px","bottom":"32px","left":"32px","right":"32px"},"blockGap":"12px"},"border":{"radius":"20px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:20px;padding-top:32px;padding-right:32px;padding-bottom:32px;padding-left:32px">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Söngur</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"ink-2"} -->
<p class="has-ink-2-color has-text-color">Lagavalið er að mestu í höndum nemandans. Við vinnum með raddbeitingu, öndun og túlkun, hvort sem þú vilt syngja popp, rokk eða klassík.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"fontSize":"small","style":{"typography":{"fontWeight":"600"}},"textColor":"accent"} -->
<p class="has-accent-color has-text-color has-small-font-size" style="font-weight:600">Rytmískur og klassískur söngur</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"style":{"spacing":{"padding":{"top":"32px","bottom":"32px","left":"32px","right":"32px"},"blockGap":"12px"},"border":{"radius":"20px"}},"backgroundColor":"dark-2","textColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group has-white-color has-text-color has-dark-2-background-color has-background" style="border-radius:20px;padding-top:32px;padding-right:32px;padding-bottom:32px;padding-left:32px">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Tónlistartækni</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"on-dark"} -->
<p class="has-on-dark-color has-text-color">Lærðu að taka upp, útsetja og búa til þína eigin tónlist í helstu forritunum.</p>
<!-- /wp:paragraph -->
<!-- wp:group {"style":{"spacing":{"blockGap":"8px"}},"layout":{"type":"flex","flexWrap":"wrap"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"style":{"spacing":{"padding":{"top":"4px","bottom":"4px","left":"12px","right":"12px"}},"border":{"radius":"999px"},"typography":{"fontWeight":"600"}},"backgroundColor":"ink","textColor":"mint","fontSize":"small"} -->
<p class="has-mint-color has-ink-background-color has-text-color has-background has-small-font-size" style="border-radius:999px;padding-top:4px;padding-right:12px;padding-bottom:4px;padding-left:12px;font-weight:600">Ableton Live</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"style":{"spacing":{"padding":{"top":"4px","bottom":"4px","left":"12px","right":"12px"}},"border":{"radius":"999px"},"typography":{"fontWeight":"600"}},"backgroundColor":"ink","textColor":"mint","fontSize":"small"} -->
<p class="has-mint-color has-ink-background-color has-text-color has-background has-small-font-size" style="border-radius:999px;padding-top:4px;padding-right:12px;padding-bottom:4px;padding-left:12px;font-weight:600">Logic Pro</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"style":{"spacing":{"padding":{"top":"4px","bottom":"4px","left":"12px","right":"12px"}},"border":{"radius":"999px"},"typography":{"fontWeight":"600"}},"backgroundColor":"ink","textColor":"mint","fontSize":"small"} -->
<p class="has-mint-color has-ink-background-color has-text-color has-background has-small-font-size" style="border-radius:999px;padding-top:4px;padding-right:12px;padding-bottom:4px;padding-left:12px;font-weight:600">GarageBand</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"style":{"spacing":{"padding":{"top":"4px","bottom":"4px","left":"12px","right":"12px"}},"border":{"radius":"999px"},"typography":{"fontWeight":"600"}},"backgroundColor":"ink","textColor":"mint","fontSize":"small"} -->
<p class="has-mint-color has-ink-background-color has-text-color has-background has-small-font-size" style="border-radius:999px;padding-top:4px;padding-right:12px;padding-bottom:4px;padding-left:12px;font-weight:600">Pro Tools</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"style":{"spacing":{"padding":{"top":"4px","bottom":"4px","left":"12px","right":"12px"}},"border":{"radius":"999px"},"typography":{"fontWeight":"600"}},"backgroundColor":"ink","textColor":"mint","fontSize":"small"} -->
<p class="has-mint-color has-ink-background-color has-text-color has-background has-small-font-size" style="border-radius:999px;padding-top:4px;padding-right:12px;padding-bottom:4px;padding-left:12px;font-weight:600">FL Studio</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:paragraph {"textColor":"on-dark","fontSize":"small"} -->
<p class="has-on-dark-color has-text-color has-small-font-size">Nemendur fá líka aðgang að Soundtrap til að taka upp í vafra og appi.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
