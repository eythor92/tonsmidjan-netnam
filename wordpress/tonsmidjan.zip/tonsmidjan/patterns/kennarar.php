<?php
/**
 * Title: Kennarar
 * Slug: tonsmidjan/kennarar
 * Categories: tonsmidjan, team
 * Description: Spjöld með kennurum skólans.
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","anchor":"kennarar","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"},"blockGap":"var:preset|spacing|50"}},"backgroundColor":"ground","layout":{"type":"constrained"}} -->
<section id="kennarar" class="wp-block-group alignfull has-ground-background-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group alignwide">
<!-- wp:heading -->
<h2 class="wp-block-heading">Kennararnir</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p><a href="/kennarar/">Allir kennarar →</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"20px"}},"layout":{"type":"grid","minimumColumnWidth":"300px"}} -->
<div class="wp-block-group alignwide">
<!-- wp:group {"className":"tsn-card","style":{"spacing":{"padding":{"top":"28px","bottom":"28px","left":"28px","right":"28px"},"blockGap":"6px"},"border":{"radius":"20px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-card has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:20px;padding-top:28px;padding-right:28px;padding-bottom:28px;padding-left:28px">
<!-- wp:paragraph {"className":"tsn-step-num","style":{"border":{"radius":"50%"},"typography":{"fontWeight":"700"},"spacing":{"margin":{"bottom":"10px"}}},"backgroundColor":"amber","textColor":"ink"} -->
<p class="tsn-step-num has-ink-color has-amber-background-color has-text-color has-background" style="border-radius:50%;margin-bottom:10px;font-weight:700">?</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">[Nafn kennara]</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"style":{"typography":{"fontWeight":"600"}},"textColor":"accent","fontSize":"small"} -->
<p class="has-accent-color has-text-color has-small-font-size" style="font-weight:600">[Hljóðfæri]</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">[Stutt kynning á kennaranum: bakgrunnur, reynsla og hvað hann kennir.]</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"tsn-card","style":{"spacing":{"padding":{"top":"28px","bottom":"28px","left":"28px","right":"28px"},"blockGap":"6px"},"border":{"radius":"20px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-card has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:20px;padding-top:28px;padding-right:28px;padding-bottom:28px;padding-left:28px">
<!-- wp:paragraph {"className":"tsn-step-num","style":{"border":{"radius":"50%"},"typography":{"fontWeight":"700"},"spacing":{"margin":{"bottom":"10px"}}},"backgroundColor":"amber","textColor":"ink"} -->
<p class="tsn-step-num has-ink-color has-amber-background-color has-text-color has-background" style="border-radius:50%;margin-bottom:10px;font-weight:700">?</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">[Nafn kennara]</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"style":{"typography":{"fontWeight":"600"}},"textColor":"accent","fontSize":"small"} -->
<p class="has-accent-color has-text-color has-small-font-size" style="font-weight:600">[Hljóðfæri]</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">[Stutt kynning á kennaranum: bakgrunnur, reynsla og hvað hann kennir.]</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"tsn-card","style":{"spacing":{"padding":{"top":"28px","bottom":"28px","left":"28px","right":"28px"},"blockGap":"6px"},"border":{"radius":"20px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group tsn-card has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:20px;padding-top:28px;padding-right:28px;padding-bottom:28px;padding-left:28px">
<!-- wp:paragraph {"className":"tsn-step-num","style":{"border":{"radius":"50%"},"typography":{"fontWeight":"700"},"spacing":{"margin":{"bottom":"10px"}}},"backgroundColor":"amber","textColor":"ink"} -->
<p class="tsn-step-num has-ink-color has-amber-background-color has-text-color has-background" style="border-radius:50%;margin-bottom:10px;font-weight:700">?</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">[Nafn kennara]</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"style":{"typography":{"fontWeight":"600"}},"textColor":"accent","fontSize":"small"} -->
<p class="has-accent-color has-text-color has-small-font-size" style="font-weight:600">[Hljóðfæri]</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">[Stutt kynning á kennaranum: bakgrunnur, reynsla og hvað hann kennir.]</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
