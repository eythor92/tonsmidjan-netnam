<?php
/**
 * Title: Verðskrá
 * Slug: tonsmidjan/verdskra
 * Categories: tonsmidjan, text
 * Description: Tafla fyrir verðskrá. Settu á síðuna „Verðskrá“ og fylltu inn.
 * Viewport Width: 1200
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"32px","bottom":"32px","left":"32px","right":"32px"}},"border":{"radius":"20px","width":"1px","color":"var:preset|color|line"}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-border-color has-white-background-color has-background" style="border-color:var(--wp--preset--color--line);border-width:1px;border-radius:20px;padding-top:32px;padding-right:32px;padding-bottom:32px;padding-left:32px">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Verðskrá [skólaár]</h3>
<!-- /wp:heading -->
<!-- wp:table {"hasFixedLayout":true,"className":"is-style-stripes"} -->
<figure class="wp-block-table is-style-stripes"><table class="has-fixed-layout"><thead><tr><th>Nám</th><th>Lengd</th><th>Verð á önn</th></tr></thead><tbody><tr><td>Hljóðfæranám, heill tími</td><td>[X] mín á viku</td><td>[VERÐ] kr.</td></tr><tr><td>Hljóðfæranám, hálfur tími</td><td>[X] mín á viku</td><td>[VERÐ] kr.</td></tr><tr><td>Söngnám</td><td>[X] mín á viku</td><td>[VERÐ] kr.</td></tr><tr><td>Tónlistartækni</td><td>[X] mín á viku</td><td>[VERÐ] kr.</td></tr><tr><td>Netnám, eitt námskeið</td><td>4 vikur</td><td>18.900 kr.</td></tr><tr><td>Netnám, öll þrjú námskeiðin</td><td>3 × 4 vikur</td><td>16.900 kr. á námskeið</td></tr></tbody></table></figure>
<!-- /wp:table -->
<!-- wp:paragraph {"textColor":"ink-2","fontSize":"small"} -->
<p class="has-ink-2-color has-text-color has-small-font-size">[Upplýsingar um frístundastyrk, systkinaafslátt og greiðsluskilmála.]</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
