<?php
/**
 * Tónsmiðjan – þemaföll.
 *
 * @package tonsmidjan
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hleður inn stílblaði þemans á vef og í ritli.
 */
function tonsmidjan_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );
}
add_action( 'after_setup_theme', 'tonsmidjan_setup' );

function tonsmidjan_styles() {
	wp_enqueue_style(
		'tonsmidjan-style',
		get_stylesheet_uri(),
		array(),
		wp_get_theme()->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'tonsmidjan_styles' );

/**
 * Flokkur fyrir mynstur Tónsmiðjunnar í ritlinum.
 */
function tonsmidjan_pattern_categories() {
	register_block_pattern_category(
		'tonsmidjan',
		array(
			'label'       => __( 'Tónsmiðjan', 'tonsmidjan' ),
			'description' => __( 'Hlutar sem passa við útlit Tónsmiðjunnar.', 'tonsmidjan' ),
		)
	);
}
add_action( 'init', 'tonsmidjan_pattern_categories' );

/**
 * Slóðir sem eru notaðar víða í mynstrunum. Breyttu hér ef þær breytast.
 */
function tonsmidjan_url( $key ) {
	$urls = array(
		'skraning' => 'https://istonsmidjan.speedadmin.dk/registration#/',
		'netnam'   => 'https://eythor92.github.io/tonsmidjan-netnam/',
	);
	return isset( $urls[ $key ] ) ? $urls[ $key ] : '#';
}
